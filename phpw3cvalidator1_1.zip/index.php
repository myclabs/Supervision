<?php
   session_start();
   if(!isset($_SESSION["textsize"]))
{
 $_SESSION["textsize"]=14;
}
  ///check for SID
  $sid=session_name()."=";
        if(isset($_COOKIE[session_name()]))
        {
         $sid.=$_COOKIE[session_name()];
        }
        else
        {
         $sid.=SID;
        }
        ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <title>Site Wide CSS/XHTML Validator</title>
   <link href="validator.css" type="text/css" rel="stylesheet" id="mainstyle" />
</head>

<body>

<?php
$do="";
$originaldir=$_SERVER["DOCUMENT_ROOT"]."/";
$domain=(!empty($_SERVER["HTTPS"]))? "https://".$_SERVER["HTTP_HOST"] :"http://".$_SERVER["HTTP_HOST"];
if (isset($_GET["do"]))
{
   $do=htmlentities($_GET["do"],ENT_QUOTES,"UTF-8");
   }

   switch($do)
   {
   case "local":





$filetypes=array("html","htm","php","asp","cf","shtml","ob","dh","css");
// Open a known directory, and proceed to read its contents

function diropen($dir,$path)
{
global $originaldir,$filetypes,$domain,$sid;
$path=$path.$dir;
    echo $path.$dir."<br /><ul>";
     if ($dh = opendir($path)) {

        while (($file = readdir($dh)) !== FALSE) {
        if ($file{0}!=".")
        {

            if (is_dir($path.$file."/"))
            {
            echo "<li>$path".$file."/</li>";

               diropen($file."/",$path);

            }
            else
            {
             echo "<li>$path".$file."</li>";
            $pathinfo=pathinfo($file,PATHINFO_EXTENSION);

           if (array_search($pathinfo,$filetypes)!==FALSE)
            {
                                $uripath=$domain."/".str_replace($originaldir,"",$path).$file;
                                if (strpos($uripath,"?")==FALSE)
                                {
                                $uripath.="?";
                                }
                                else
                                {
                                 $uripath.="&amp;";
                                }
                                $uripath.=$sid;
            $uripath=urlencode($uripath);

            echo "<br /><iframe frameborder=\"0\" width=\"100%\" height=\"150\" src=\"runvalidator.php?data=$uripath&amp;type=css\"></iframe><br />";

            if ($pathinfo!="css")
            {
             echo  "<br /><iframe frameborder=\"0\" width=\"100%\" height=\"150\"  src=\"runvalidator.php?data=$uripath&amp;type=xhtml\"></iframe><br />";
            }


            }

            }
          }
        }

        closedir($dh);
    }
     echo "</ul><br />";
}
if (!isset($_POST["urls"]))
          {
           exit("URLS NOT POSTED<br />");
          }

          $urls=htmlentities($_POST["urls"],ENT_QUOTES,"UTF-8");
          $urls=",".$urls;
          $urls=explode(",",$urls);
      if (!isset($_POST["skiplocal"]))
      {
      echo "Scanning paths...$originaldir<br />";
if (is_dir($originaldir)) {

   diropen("",$originaldir);
}
else
{
 echo "Not a valid path make sure you have a / at the end<br />";
}
}
   if (count($urls)>1)
   {
echo "Scanning additional files...";

          foreach($urls as $val)
          {
          if ($val!="")
          {
           $uri=$domain."/".trim($val);
           $uri=urlencode($uri);

            echo "<b>Validating $val</b><br /><iframe frameborder=\"0\" width=\"100%\" height=\"150\" src=\"runvalidator.php?data=$uri&amp;type=css\"></iframe><br />";

            if (substr($val,strlen($val)-1,-4)!=".css")
            {
             echo  "<br /><iframe frameborder=\"0\" width=\"100%\" height=\"150\"  src=\"runvalidator.php?data=$uri&amp;type=xhtml\"></iframe><br />";
            }
          }
          }
          }


   break;
         case "remote":
          if (!isset($_POST["urls"]))
          {
           exit("URLS NOT POSTED<br />");
          }

          $urls=htmlentities($_POST["urls"],ENT_QUOTES,"UTF-8");
          $urls=explode(",",$urls);

          foreach($urls as $val)
          {
            $uri=trim($val);
          $uri=urlencode($uri);

            echo "<b>Validating $val</b><br /><iframe frameborder=\"0\" width=\"100%\" height=\"150\" src=\"runvalidator.php?data=$uri&amp;type=css\"></iframe><br />";

            if (substr($val,strlen($val)-1,-4)!=".css")
            {
             echo  "<br /><iframe frameborder=\"0\" width=\"100%\" height=\"150\"  src=\"runvalidator.php?data=$uri&amp;type=xhtml\"></iframe><br />";
            }
          }
         break;
   default:

    ?>
    <form action="index.php?do=local" method="post">
    Additional files to scan (I.E. URIs with a query string) separated by , please include the path from <?php echo $originaldir; ?><br /> <textarea rows="10" cols="25" name="urls"></textarea><br />
Check to only scan additional files <input type="checkbox" name="skiplocal" /> <br />
    <input type="submit" value="Scan Local Files" /></form><br />Scans recusively from <?php echo $originaldir; ?> of the web server.<br /><br />
<hr />
<br />
Scan Remote Files<br />
<form action="index.php?do=remote" method="post">
Please input the urls you wish to check, using the full http:// or https:// prefix, separate each url with a  , (no need for a space).<br />The validator can scan pages that require logins but to do this you must find the SID of your login.<br />
Login to the site, check your cookies for a cookie with a long string of random characters and letters and the name of the cookie (on php sites this is usually PHPSESSID), then add it to the querystring of your url<br />    <br />
<textarea rows="10" cols="25" name="urls"></textarea><br />
<input type="submit" value="Scan" /></form>
    <?php
   break;
   }





?>

</body>

</html>