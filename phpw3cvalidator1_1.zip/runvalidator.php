﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <title>Site Wide CSS/XHTML Validator</title>
  <link href="validator.css" type="text/css" rel="stylesheet" id="mainstyle" />
</head>

<body>

<?php
//make compatible with php 4
if (!function_exists("stream_get_contents"))
{

 function stream_get_contents($handle,$bytes=-1)
 {
 $checkbytes=($bytes==-1) ? FALSE :TRUE;
    $contents='';
    while (!feof($handle)) {
  $contents .= fread($handle, 1024);
  if ($checkbytes===TRUE)
  {
  $bytes-=1024;
   if ($bytes<=0)
   {
    break;
   }
  }
}
 return $contents;
 }

}


$data=htmlentities($_GET["data"],ENT_QUOTES,"UTF-8");
$type=htmlentities($_GET["type"],ENT_QUOTES,"UTF-8");
    //example of valid reponse header for xhtml/html X-W3C-Validator-Status: Valid X-W3C-Validator-Errors: 0 Connection: close
          //example of invalid reponse header for xhtml/html X-W3C-Validator-Status: Invalid X-W3C-Validator-Errors: 1 Connection: close
function validatorconnect($data,$type)
    {
        echo "Validating ".(($type=="css")? "CSS": "HTML/XHTML")." for<br />$data<br />";
        //validating css or xhtml?
    $host=($type=="css") ? "jigsaw.w3.org" : "validator.w3.org";
    //connect to validating site
        $open = @fsockopen($host, 80, $errorNumber, $errorString);
                     if (!$open)
                     {
                      echo "Unable to connect! Error number $errorNumber; Detail $errorString<br />";
                      return;
                     }
                     else
                     {
                      echo "Connection established...<br />";
                     }

        ///send information of what is to be validated to host
        $requestHeader = ($type=="css")? "GET /css-validator/validator?uri=$data HTTP/1.1\r\n" : "GET /check?uri=$data HTTP/1.1\r\n";
        $requestHeader.= "Host: $host\r\n";
        $requestHeader.= "User-Agent: PHPW3CValidator.obsidianproject.co.uk";
        $requestHeader.= "Content-Type: application/x-www-form-urlencoded\r\n";
        $requestHeader.= "Connection: close\r\n\r\n";

       fwrite($open, $requestHeader);

       //read response for CSS  only works on php 5.x
if ($type=="css")
{
$search=htmlentities("<a href=\"#errors\">Errors",ENT_QUOTES,"UTF-8");
$contents = stream_get_contents($open,1280);
   $contents=htmlentities($contents,ENT_QUOTES,"UTF-8");
   $checkerrors=strpos($contents,$search);
   if ($checkerrors===FALSE)
   {
$response="<span class=\"valid\">Valid CSS<br /></span>";
}
else
{
$len=$checkerrors+strlen($search);
 $response="<span class=\"error\">Invalid CSS - ".substr($contents,$len,strpos($contents,"&lt;/a&gt;",$checkerrors)-$len)." errors<br /></span>";
}


}
else
{
//read headers for xhtml only works on php 5.x
 $contents = stream_get_contents($open,512);

    $findvalid=strpos($contents,"X-W3C-Validator-Status: ");
    $finderrors=strpos($contents,"X-W3C-Validator-Errors: ");
    $findend=strpos($contents,"Connection:");
    if ($findvalid===FALSE || $finderrors===FALSE || $findend===FALSE)
    {
     echo "INVALID HEADER RESPONSE CHECK URL<br />";
     return;
    }
    $findvalid+=strlen("X-W3C-Validator-Status:");

    $isvalid=trim(substr($contents,$findvalid,$finderrors-$findvalid));
     $finderrors+=strlen("X-W3C-Validator-Errors:");

    $class=($isvalid=="Valid")? "valid" : "error";
    $numerrors=substr($contents,$finderrors,$findend-$finderrors);
    $response="<span class=\"$class\">Validation: $isvalid<br />Errors: $numerrors<br /></span>";
    }

fclose($open);
$response.="<a href=\"http://$host".(($type=="css")? "/css-validator/validator?uri=$data" : "/check?uri=$data")."\" target=\"_blank\" />View results</a><br />";
return $response;
    }
//example uri http://validator.w3.org/check?uri=http%3A%2F%2Fwww.obsidianproject.co.uk
echo validatorconnect($data,$type);


?>
</body>

</html>