PHPW3CValidator by obsidiandh

http://phpw3cvalidator.sourceforge.net/

PHPW3CValidator is a tool for use on phpwebsites to validtae the entire site or select documents for w3c xhtml/html and css validation

To install create a new directory in your web root

Upload the files index.php validator.css and runvalidator.php to this directory

Point your web browser to the directory

Click "scan local" to check all files in your web root.

To edit where the scan starts from open index.php in a plain text editor or web editor, change line 41

$originaldir=$_SERVER["DOCUMENT_ROOT"]."/";

To $originaldir="yourdirectory";

If safe mode is on and php isn't compiled in a cgi module it won't work as the script will be run under the nobody user not the owner of the script.

replacing yourdirectory with the path you want, remember to end the directory in a /

To give feedback or donate please visit the website :)

Enjoy!

[CHANGE LOG]
18th Oct 2007
Version 1.1
Now works on php4 and php5